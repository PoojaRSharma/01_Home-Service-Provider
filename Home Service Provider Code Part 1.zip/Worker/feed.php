<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <script src="https://code.iconify.design/iconify-icon/1.0.0/iconify-icon.min.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hist.css">
    <title>Customer feedback</title>
    <style>

    </style>
</head>

<body>

    <div class="wrapper">
        <!--Top menu -->
        <div class="section">
            <div class="top_navbar">
                <div class="hamburger">
                    <a href="#">
                        <i class="fas fa-bars"></i>
                    </a>
                </div>
            </div>

        </div>
        <div class="sidebar">
            <!--profile image & text-->
            <div class="profile">
                <img src="girl.png" alt="profile_picture">
                <h3>Vanya Hargrevees</h3>
                <p>Cleaner</p>
            </div>
            <!--menu item-->
            <ul>
                <li>
                    <a href="http://127.0.0.1:5500/Worker/Dashboard.html">
                        <span class="icon"><i class="fas fa-desktop"></i></span>
                        <span class="item">My Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="http://localhost:3000/Worker/history.php#">
                        <span class="icon">
                            <iconify-icon icon="cil:history"></iconify-icon>
                        </span>
                        <span class="item">Work History</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="icon">
                            <iconify-icon icon="emojione-monotone:money-bag"></iconify-icon>
                        </span>
                        <span class="item">Payment</span>
                    </a>
                </li>
                <li>
                    <a href="http://localhost:3000/Worker/feed.php" class="active">
                        <span class="icon">
                            <iconify-icon icon="codicon:feedback"></iconify-icon>
                        </span>
                        <span class="item">Customers Feedback</span>
                    </a>
                </li>
                <li>
                    <a href="http://127.0.0.1:5500/Worker/To-Do-List%20Of%20Admin.html">
                        <span class="icon">
                            <iconify-icon icon="dashicons:feedback"></iconify-icon>
                        </span>
                        <span class="item">To-do-list</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    </div>
    <div class="cards">
        <section class="ca" id="dash">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-header clearfix">
                            <h2 class="pull-left">Work Histoy</h2>
                        </div>
                        <?php
                        include 'connection.php';
                        $result = mysqli_query($conn, "SELECT * FROM custfeed");
                        ?>
                        <?php
                        if (mysqli_num_rows($result) > 0) {
                        ?>
                            <table style="width: 850px; margin-top:50px; margin-left:50px">
                                <tr>
                                    <td>Arriving of worker</td>
                                    <td>Service Satisfaction</td>
                                    <td>Behavior of Worker</td>
                                    <td>Assisting the Questions</td>
                                    <td>Overall Experience</td>
                                <?php
                                $i = 0;
                                while ($row = mysqli_fetch_array($result)) {
                                ?>
                                    <tr>
                                        <td><?php echo $row["one"]; ?>/10</td>
                                        <td><?php echo $row["two"]; ?>/10</td>
                                        <td><?php echo $row["three"]; ?>/10</td>
                                        <td><?php echo $row["four"]; ?>/10</td>
                                        <td><?php echo $row["five"]; ?>/10</td>
                                        <!-- <td>
                                            <form action="del.php" method="post"><input type="button" onclick='alert("deleted from cart")' class="btnnn" value="delete" style="margin-top: 10px;"></form>
                                        </td> -->
                                    </tr>
                                <?php
                                    $i++;
                                }
                                ?>
                            </table>
                        <?php
                        } else {
                            echo "No service have been added";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script>
        var hamburger = document.querySelector(".hamburger");
        hamburger.addEventListener("click", function () {
            document.querySelector("body").classList.toggle("active");
        })
    </script>
</body>

</html>